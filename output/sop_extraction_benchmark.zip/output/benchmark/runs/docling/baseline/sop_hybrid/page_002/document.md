<!-- image -->

## CÔNG TY TNHH THIÉT BỊ NOVA

Hệ thống quản lý chất Iượng / Quality Management System QP-74-02 Phiên bản 03 Ngày hiệu lực: 15/10/2026

## LỊCH SỬ BAN HÀNH VÀ PHÊ DUYỆT

Các ô gộp; nội dung nhiều dòng và chữ xoay được bảo toàn khi trích xuất. phải

| Lần sửa   | Ngày       | Mục     | Nội dung đổi thay                                       | Người soạn        | Phê duyệt         |
|-----------|------------|---------|---------------------------------------------------------|-------------------|-------------------|
| 01        | 12/03/2024 | Toàn bộ | Ban hành lần đầu. Bổ sung hướng dẫn kiểm tra thiết bị:  | Nguyễn An         | Trần Binh         |
| 01        | 12/03/2024 | Phụ lục | Biểu mẫu QP-74-02-F6 và danh mục thiết bị QC-017        | Lê Hà             | Trần Binh         |
| 02        | 08/06/2025 | 4.2     | Sửa tần suất hiệu chuẩn từ 12 thành 6 tháng. tháng      | Đỗ Huy            | Vũ Mai            |
| 03        | 15/10/2026 |         |                                                         | Phạm Mỹ           | Vũ Mai            |
| 1 03      | 15/10/2026 | 5.2     | Phân trách nhiệm QA và bộ phận Sản xuất. công           | Phạm Mỹ           | Vũ Mai            |
| 03        | 15/10/2026 |         | Hồ sơ lưu tối thiểu 03 năm. Record retention: 3 years . | Nguyễn An         | Trần Bình         |
| 03        | 15/10/2026 | Ghi chú | Dấu Đã kiểm tra và phê duyệt:                           | Lê Hà / Trần Binh | Lê Hà / Trần Binh |

Xác nhận Approval: Nội dung này là dữ liệu hồ sơ doanh nghiệp. giả không phải